function normalizeProfileId(b){return b.trim().toLowerCase()}
document.getElementById("addprofilebtn").addEventListener("click",function(){const b=encodeURIComponent(document.getElementById("profileid").value);window.open(`https://www.google.com/maps/search/${b}`)});
