chrome.runtime.onInstalled.addListener(function(a){"install"==a.reason&&chrome.runtime.setUninstallURL&&chrome.runtime.setUninstallURL("https://7thclub.com")});
