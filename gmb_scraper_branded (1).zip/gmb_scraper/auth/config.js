var config={host:"https://7thclub.com",productId:"gmbscraper",feedback_url:"https://7thclub.com"};
